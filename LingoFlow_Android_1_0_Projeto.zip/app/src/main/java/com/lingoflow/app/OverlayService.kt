package com.lingoflow.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.drawable.GradientDrawable

class OverlayService : Service() {
 private lateinit var wm: WindowManager
 private var bubble: TextView? = null
 override fun onBind(intent:Intent?):IBinder? = null
 override fun onStartCommand(intent:Intent?, flags:Int, startId:Int):Int {
  if(!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
  if(!::wm.isInitialized) wm=getSystemService(WINDOW_SERVICE) as WindowManager
  bubble?.let { wm.removeView(it) }; bubble=null
  val bar=intent?.getStringExtra("mode")=="bar"
  val view=TextView(this).apply {
   text=if(bar) "🌐 LingoFlow · Toque para traduzir" else "🌐"
   textSize=if(bar) 17f else 26f
   gravity=Gravity.CENTER
   setTextColor(Color.WHITE)
   background=GradientDrawable().apply { setColor(Color.rgb(37,99,235)); cornerRadius=if(bar) 28f else 100f }
   setOnClickListener { startActivity(Intent(this@OverlayService,MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP) }) }
  }
  val p=WindowManager.LayoutParams(if(bar) WindowManager.LayoutParams.MATCH_PARENT else 150,if(bar) 110 else 150,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT)
  p.gravity=if(bar) Gravity.BOTTOM else Gravity.END or Gravity.CENTER_VERTICAL
  wm.addView(view,p); bubble=view
  return START_NOT_STICKY
 }
 override fun onDestroy() { bubble?.let { wm.removeView(it) }; bubble=null; super.onDestroy() }
}
