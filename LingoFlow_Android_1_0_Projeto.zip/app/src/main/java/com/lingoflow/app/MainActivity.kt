package com.lingoflow.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.graphics.Color
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {
 private lateinit var input: EditText
 private lateinit var output: TextView
 private lateinit var from: Spinner
 private lateinit var to: Spinner
 private var last = ""
 private val labels = arrayOf("Português", "Inglês", "Chinês", "Espanhol", "Italiano", "Francês", "Alemão", "Japonês")
 private val codes = arrayOf("pt-BR", "en-US", "zh-CN", "es-ES", "it-IT", "fr-FR", "de-DE", "ja-JP")
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val outer = ScrollView(this); val col = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,32,24,28); setBackgroundColor(Color.rgb(244,247,252)) }; outer.addView(col)
  fun title(s:String) { col.addView(TextView(this).apply { text=s; textSize=22f; setTextColor(Color.rgb(30,65,140)); setPadding(0,14,0,12) }) }
  fun button(s:String, f:()->Unit) { col.addView(Button(this).apply { text=s; setOnClickListener { f() } }) }
  title("LingoFlow 🌐")
  col.addView(TextView(this).apply { text="O mundo fala. Você entende."; textSize=15f })
  title("Idioma original")
  from=Spinner(this); from.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,labels); col.addView(from)
  title("Traduzir para")
  to=Spinner(this); to.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,labels); to.setSelection(1); col.addView(to)
  title("Mensagem")
  input=EditText(this).apply { hint="Digite ou compartilhe uma mensagem"; minLines=3; gravity=android.view.Gravity.TOP }; col.addView(input)
  button("Traduzir agora") { translate() }
  title("Tradução")
  output=TextView(this).apply { text="A tradução aparecerá aqui."; textSize=18f; setPadding(4,12,4,20) }; col.addView(output)
  button("Copiar tradução") { if(last.isNotBlank()) { val cm=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(android.content.ClipData.newPlainText("LingoFlow",last)); Toast.makeText(this,"Copiado",Toast.LENGTH_SHORT).show() } }
  button("Responder no WhatsApp") { if(last.isNotBlank()) { val i=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,last); setPackage("com.whatsapp") }; try { startActivity(i) } catch(e:Exception) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,last) },"Compartilhar tradução")) } } }
  title("Janela flutuante")
  button("Ativar bolinha azul") { overlay("bubble") }
  button("Ativar barra inferior") { overlay("bar") }
  button("Desativar janela flutuante") { stopService(Intent(this,OverlayService::class.java)) }
  col.addView(TextView(this).apply { text="Versão experimental. Mensagens enviadas ao MyMemory para tradução. Não use informações confidenciais. A bolinha e a barra abrem o tradutor; não leem automaticamente o WhatsApp."; textSize=12f; setPadding(0,24,0,0) })
  setContentView(outer)
  if(intent?.action==Intent.ACTION_SEND && intent.type=="text/plain") input.setText(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty())
 }
 private fun overlay(mode:String) {
  if(!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); Toast.makeText(this,"Autorize e volte para ativar",Toast.LENGTH_LONG).show(); return }
  startService(Intent(this,OverlayService::class.java).putExtra("mode",mode))
  Toast.makeText(this,"Janela ativada",Toast.LENGTH_SHORT).show()
 }
 private fun translate() {
  val q=input.text.toString().trim(); if(q.isEmpty()) { output.text="Digite uma mensagem."; return }
  val src=codes[from.selectedItemPosition]; val dst=codes[to.selectedItemPosition]
  if(src==dst) { last=q; output.text=q; return }
  output.text="Traduzindo..."
  Thread {
   try {
    val url="https://api.mymemory.translated.net/get?q="+URLEncoder.encode(q,"UTF-8")+"&langpair="+URLEncoder.encode("$src|$dst","UTF-8")
    val c=URL(url).openConnection() as HttpURLConnection
    c.connectTimeout=12000; c.readTimeout=12000
    try {
     if(c.responseCode!=200) throw Exception("HTTP ${c.responseCode}")
     val obj=JSONObject(c.inputStream.bufferedReader().use { it.readText() })
     if(obj.optInt("responseStatus")!=200) throw Exception(obj.optString("responseDetails","Erro do tradutor"))
     var translated=obj.getJSONObject("responseData").getString("translatedText")
     if(translated.equals(q,ignoreCase=true)) { val matches=obj.optJSONArray("matches"); if(matches!=null) for(i in 0 until matches.length()) { val m=matches.optJSONObject(i)?:continue; val candidate=m.optString("translation"); if(candidate.isNotBlank() && !candidate.equals(q,true) && m.optString("target").startsWith(dst.take(2),true)) { translated=candidate; break } } }
     val result=translated; runOnUiThread { last=result; output.text=result }
    } finally { c.disconnect() }
   } catch(e:Exception) { runOnUiThread { output.text="Falha na tradução: ${e.message}" } }
  }.start()
 }
}
