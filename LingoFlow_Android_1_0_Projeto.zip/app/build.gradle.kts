plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.lingoflow.app"; compileSdk = 35
 defaultConfig { applicationId = "com.lingoflow.app"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0-test" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
